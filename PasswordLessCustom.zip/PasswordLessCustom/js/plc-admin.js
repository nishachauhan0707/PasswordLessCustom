/**
 * Expanded Ad Tool admin custom Script
 */

jQuery(document).ready(function($) {

	function copyToClipboard(element) {
		var $temp = $("<input>");
	    $("body").append($temp);
	    $temp.val($(element).text()).select();
	    document.execCommand("copy");
	    $temp.remove();
	}

	$('#plc_shortcode').on('click', function() {
      	var content = $(this).val();
      	copyToClipboard('.plc_short_text');
      	$(this).val("Copied!");
      	setTimeout(function() {
        	$('#plc_shortcode').val(content);
     	}, 1200);
    });

});