/**
 * PasswordLessCustom frontend Preview custom Script
 */

jQuery(document).ready(function($) {

	var ajax_url = localize_data.ajax_url ; 

	$('#plc_login_generator').on('submit', function(e) {
        
		var user = $('#plc_username_email').val();
		if ( $.trim(user) == '' ) {
			e.preventDefault();
			alert("Please Fill Username or Email");
			$('#plc_username_email').focus();
		}

	});


	jQuery("#plc_otp").focus(function(){
		jQuery("#otp-msg").css('display' , 'none') ; 
	});
        
 

jQuery(document).on('click','#plc_verify_otp',function(){

		var otp = jQuery('#plc_otp').val() ;
		var user_id = jQuery('#plc_user_id').val() ;
		var token = jQuery('#plc_token').val();
		var order_id = jQuery("#plc_order_id").val();
		jQuery(this).val('Verifying...');

		var ajax_data = {
			"action" : "mwb_plc_verify_otp",
			'plc_otp' : otp,
			'plc_user_id': user_id,
		    'plc_token' : token,
		    'plc_order_id' : order_id,
		}

		jQuery.ajax({
			url: ajax_url,
			data: ajax_data,
			type: 'post',
			dataType: "json",
			success: function (response){

				if(response.success){

					window.location.href = response.link;

				}else{

					jQuery("#plc_verify_otp").val('Verify');
					jQuery("#otp-msg").css('display' , 'block') ; 
				}
			}
		});
	});

});