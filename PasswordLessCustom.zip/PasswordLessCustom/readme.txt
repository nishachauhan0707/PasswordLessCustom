 Plugin Name: PasswordLessCustom
 Description: Enter an email or username to get link and login without password.
 Version: 1.0.0
 Author: Nisha Chauhan
 License:later
 Text Domain: PasswordLessCustom

How to use:
Put this Short Code [PasswordLessCustom] In which page you want