<?php
/**
 * PasswordLessCustom User Logs dashboard
 */
?>

<div id="plc_user_log_wrap" class="wrap">

	<h2><?php _e( '<strong>Passwordless Login Logs</strong>', 'plc-custom' ); ?></h2>
	<hr />
	<table id="plc_user_logs_table" class="wp-list-table widefat fixed striped plc_user_logs_table">
		<thead>
			<tr>
				<th><?php _e( 'ID', 'plc-custom'  ); ?></th>
				<th><?php _e( 'Username', 'plc-custom'  ); ?></th>
				<th><?php _e( 'Email', 'plc-custom'  ); ?></th>
                                <th><?php _e( 'Login Link', 'plc-custom'  ); ?></th>
				<th><?php _e( 'Date/Time', 'plc-custom'  ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php
			global $wpdb;

			$table_name = $wpdb->prefix . 'plc_logs';
			$data = $wpdb->get_results("SELECT * FROM $table_name ORDER BY ID DESC");

			$log_num = count($data);
			if ( $log_num != get_option( 'plc_total_logins' ) ) {
				update_option( 'plc_total_logins', $log_num );
			} 

			foreach ($data as $key => $value) {
			?>
			<tr>
				<td><?php echo $value->id; ?></td>
				<td><?php echo $value->username; ?></td>
				<td><?php echo $value->email; ?></td>
                                <td><?php echo $value->plc_loginlink; ?></td>
				<td><?php echo $value->date; ?></td>
			</tr>
			<?php
			}
		?>
		</tbody>
	</table>

</div>