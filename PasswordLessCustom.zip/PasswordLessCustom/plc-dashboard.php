<?php
/**
 * PasswordLessCustom Admin dashboard
 */

if ( $_POST ) {

	if ( $_POST['plc_expire_time'] ) {
		update_option( 'plc_expire_time', $_POST['plc_expire_time'] );
                //update_option( 'plc_passlinkexpire_time', $_POST['plc_usage_count'] );
	}

	if ( $_POST['plc_usage_count'] ) {
		update_option( 'plc_usage_count', $_POST['plc_usage_count'] );
	}

}

$plc_expire_time = get_option( 'plc_expire_time', '1' );
$plc_usage_count = get_option( 'plc_usage_count', '1' );

?>

<div id="plc_wrap" class="wrap plc_wrap">

	<div class="plc_badge"></div>
	<h2><?php printf( __( '<strong>Passwordless Custom</strong> <small>v.</small>%s', 'ss-generator' ), PLC_VERSION ); ?></h2>
	<h3 >
            <a href="<?php echo admin_url();?>/admin.php?page=plc_user_logs" target="_blank" ><strong><?php echo get_option('plc_total_logins', '0'); ?></strong>
		<?php _e('successful logins without passwords.', 'ss-generator'); ?></a>
	</h3>
	<hr />
	<div class="plc_content">
		<span class="plc_short_title"><?php _e( 'Shortcode', 'ss-generator' ); ?></span>
		<span class="plc_short_text"><?php _e( '[PasswordLessCustom]', 'ss-generator' ); ?></span>
		<span class="plc_short_copy">
			<input id="plc_shortcode" class="plc_shortcode button button-primary" type="button" name="plc_shortcode" value="<?php _e( 'Copy', 'ss-generator' ); ?>">
		</span>
		<form id="plc_setting" name="plc_setting" method="POST" class="plc_setting">
			<h2><?php esc_html_e( 'Settings', 'ss-generator' ); ?></h2>
			<div class="plc_form_row">
				<label><?php esc_html_e( 'Set number of times a link can be used', 'ss-generator' ); ?></label>
				<input type="number" name="plc_usage_count" min="1" value="<?php echo $plc_usage_count ;?>">
			</div>
			<div class="plc_form_row">
				<label><?php esc_html_e( 'Set expiration time for the passwordless link generated', 'ss-generator' ); ?></label>
				<select id="plc_expire_time" class="plc_expire_time" name="plc_expire_time">
					<option value="1" <?php echo ( $plc_expire_time == '1' ) ? 'selected' : ''; ?>><?php esc_html_e( '1 Day', 'ss-generator' ); ?></option>
					<option value="2" <?php echo ( $plc_expire_time == '2' ) ? 'selected' : ''; ?>><?php esc_html_e( '2 Days', 'ss-generator' ); ?></option>
					<option value="3" <?php echo ( $plc_expire_time == '3' ) ? 'selected' : ''; ?>><?php esc_html_e( '3 Days', 'ss-generator' ); ?></option>
					<option value="4" <?php echo ( $plc_expire_time == '4' ) ? 'selected' : ''; ?>><?php esc_html_e( '4 Days', 'ss-generator' ); ?></option>
					<option value="5" <?php echo ( $plc_expire_time == '5' ) ? 'selected' : ''; ?>><?php esc_html_e( '5 Days', 'ss-generator' ); ?></option>
					<option value="6" <?php echo ( $plc_expire_time == '6' ) ? 'selected' : ''; ?>><?php esc_html_e( '6 Days', 'ss-generator' ); ?></option>
					<option value="7" <?php echo ( $plc_expire_time == '7' ) ? 'selected' : ''; ?>><?php esc_html_e( '1 Week', 'ss-generator' ); ?></option>
					<option value="14" <?php echo ( $plc_expire_time == '14' ) ? 'selected' : ''; ?>><?php esc_html_e( '2 Weeks', 'ss-generator' ); ?></option>
					<option value="21" <?php echo ( $plc_expire_time == '21' ) ? 'selected' : ''; ?>><?php esc_html_e( '3 Weeks', 'ss-generator' ); ?></option>
					<option value="30" <?php echo ( $plc_expire_time == '30' ) ? 'selected' : ''; ?>><?php esc_html_e( '1 Month', 'ss-generator' ); ?></option>
					<option value="90" <?php echo ( $plc_expire_time == '90' ) ? 'selected' : ''; ?>><?php esc_html_e( '3 Months', 'ss-generator' ); ?></option>
					<option value="180" <?php echo ( $plc_expire_time == '180' ) ? 'selected' : ''; ?>><?php esc_html_e( '6 Months', 'ss-generator' ); ?></option>
					<option value="365" <?php echo ( $plc_expire_time == '365' ) ? 'selected' : ''; ?>><?php esc_html_e( '1 Year', 'ss-generator' ); ?></option>
				</select>
			</div>
			<div class="plc_form_row">
				<input type="submit" name="plc_save_settings" id="plc_save_settings" class="plc_save_settings button button-primary" value="<?php esc_html_e( 'Save', 'ss-generator' ); ?>">
			</div>
		</form>
	</div>

</div>