<?php

/**
 * @package PasswordLessCustom
**/

/*
 Plugin Name: PasswordLessCustom
 Description: Enter an email or username to get link and login without password.
 Version: 1.0.0
 Author: Nisha Chauhan
 License:later
 Text Domain: PasswordLessCustom
**/

/**
 * Constant Definitions
 */
define( 'PLC_VERSION', '1.0.0' );
define( 'PLC_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . dirname( plugin_basename( __FILE__ ) ) );
define( 'PLC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );


/**
 * Register a new custom menu page.
 */
function register_plc_menu_page() {
    add_menu_page(
        __( 'Passwordless Custom', 'ss-generator' ),
        __( 'Passwordless Custom', 'ss-generator' ),
        'manage_options',
        'PasswordLessCustom',
        'plc_menu_page_content',
        PLC_PLUGIN_URL . 'img/icon.png',
        68
    );
    
    add_menu_page(
        __( 'Passwordless Logs', 'ss-generator' ),
        __( 'Passwordless Logs', 'ss-generator' ),
        'manage_options',
        'plc_user_logs',
        'plc_submenu_user_logs_content',
            PLC_PLUGIN_URL . 'img/icon.png',
        69
    );
}
add_action( 'admin_menu', 'register_plc_menu_page' );


/**
 * Display a new custom menu page content
 */
function plc_menu_page_content() {
    require_once PLC_PLUGIN_DIR . '/plc-dashboard.php';
}


/**
 * Display a new submenu item page content
 */
function plc_submenu_user_logs_content() {
    require_once PLC_PLUGIN_DIR . '/plc-user-logs.php';
}


/**
 * Add script and stylesheet to the backend
 */
function plc_admin_assets() {

	wp_enqueue_style ( 'plc_admin_menu_css', PLC_PLUGIN_URL . 'css/plc-admin-menu.css', '' );

	if ( $_GET['page'] == 'PasswordLessCustom' || $_GET['page'] == 'plc_user_logs' ) {
	    wp_enqueue_style ( 'plc_admin_css', PLC_PLUGIN_URL . 'css/plc-admin.css', '' );
	    wp_enqueue_script( 'plc_admin_js', PLC_PLUGIN_URL . 'js/plc-admin.js', array( 'jquery' ) );
	}

}
add_action('admin_enqueue_scripts', 'plc_admin_assets');


/**
 * Add scripts and styles to the frontend
 */
function plc_custom_assets() {

	if ( !wp_script_is('jquery') ) {
    	wp_enqueue_script('jquery');
  	}

  	if ( file_exists( PLC_PLUGIN_DIR . '/css/plc-custom.css' ) ) {
	  	wp_enqueue_style ( 'plc_custom_css', PLC_PLUGIN_URL . 'css/plc-custom.css', '' );
  	}

  	if ( file_exists( PLC_PLUGIN_DIR . '/js/plc-custom.js' ) ) {
	  	
  		$localize_data = array('ajax_url' => admin_url('admin-ajax.php')) ; 
  		
  		wp_register_script( 'plc_custom_js', PLC_PLUGIN_URL . 'js/plc-custom.js', array( 'jquery') );

  		wp_localize_script('plc_custom_js' , 'localize_data' , $localize_data) ; 
	  	
	  	wp_enqueue_script('plc_custom_js');
  	}

}
add_action('wp_enqueue_scripts', 'plc_custom_assets');

/**
 * Shortcode for the PasswordLessCustom
 */
function plc_preview_shortcode( $atts ) {

require_once  PLC_PLUGIN_DIR . '/plc-shortcode.php';

}

add_shortcode( 'PasswordLessCustom', 'plc_preview_shortcode' );

add_filter( 'widget_text', 'shortcode_unautop' );
add_filter( 'widget_text', 'do_shortcode', 11 );







/**
 * Returns the current page URL
 */
function plc_curpageurl() {

    $req_uri = $_SERVER['REQUEST_URI'];

    $home_path = trim( parse_url( home_url(), PHP_URL_PATH ), '/' );
    $home_path_regex = sprintf( '|^%s|i', preg_quote( $home_path, '|' ) );

    /* Trim path info from the end and the leading home path from the front. */
    $req_uri = ltrim( $req_uri, '/' );
    $req_uri = preg_replace( $home_path_regex, '', $req_uri );
    $req_uri = trim( home_url(), '/' ) . '/' . ltrim( $req_uri, '/' );

    return $req_uri;

}


/**
 * Login Using generated link
 */
function plc_passwordless_login_via_url() {

	add_option( "plc_version", "1.0.0" );

	if ( isset( $_GET['token'] ) && isset( $_GET['uid'] ) && isset( $_GET['plc_nonce'] ) ) {

		
		$req_uri = $_SERVER['REQUEST_URI'] ; 	

		$uid = sanitize_key( $_GET['uid'] );
		$token = sanitize_key( $_REQUEST['token'] );
		$plc_nonce = sanitize_key( $_REQUEST['plc_nonce'] );
		
		$validate_otp = (isset($_GET['otp'])) ? true : false ;

		$hash_meta = get_user_meta( $uid, 'plc_' . $uid, true );
		$hash_meta_expiration = get_user_meta( $uid, 'plc_' . $uid . '_expiration', true );
		$usage_count = get_user_meta( $uid, 'plc_' . $uid .'_usage_count', true );

		$max_usage_count = get_option( 'plc_usage_count', '1' );

		if(empty($usage_count)){
			$usage_count = 1 ;
		}

		$arr_params = array( 'uid', 'token', 'plc_nonce' );
		$current_page_url = remove_query_arg( $arr_params, plc_curpageurl() );
                

		require_once( ABSPATH . 'wp-includes/class-phpass.php');
		$wp_hasher = new PasswordHash(8, TRUE);
		$time = time();

		if ( ! $wp_hasher->CheckPassword( $token . $hash_meta_expiration, $hash_meta ) || $hash_meta_expiration < $time || is_user_logged_in() || $usage_count > $max_usage_count) {

			wp_redirect( $current_page_url . '?plc_err_token=true' );
			exit;

		} else {	


			if( $validate_otp ){
				
				return ; 
			}

			wp_set_auth_cookie( $uid );
			update_user_meta( $uid, 'plc_cookie', 'session_user' );
			update_user_meta( $uid, 'plc_' . $uid .'_usage_count', ($usage_count + 1) );
			
			global $wpdb;

			$table_name = $wpdb->prefix . 'plc_logs';
			$user = get_user_by( 'ID', $uid );
			$username = $user->user_login;
			$useremail = $user->user_email;

			$wpdb->insert( 
				$table_name, 
				array( 
					'username' 	=> $username, 
					'email' 	=> $useremail,
                                        'plc_loginlink' => $req_uri,
					'date' 		=> current_time( 'mysql' )
				) 
			);
                        //$afterlogin_page_url=home_url()."/my-account/";
			$total_logins = get_option( 'plc_total_logins', 0 );
			update_option( 'plc_total_logins', $total_logins + 1 );
			wp_redirect( apply_filters('plc_after_login_temp_redirect', $current_page_url ) );
                   
			exit;

		}

	}

}
add_action( 'init', 'plc_passwordless_login_via_url' );


/**
 * Install User logs db table when the plugin is activated
 */
function plc_db_install() {

	global $wpdb;

	$table_name = $wpdb->prefix . 'plc_logs';	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id 			mediumint(9) NOT NULL AUTO_INCREMENT, 
		username 	varchar(55) NOT NULL, 
		email 		varchar(80) NOT NULL,
                plc_loginlink 	varchar(255) NOT NULL,
		date 		datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";
        
        $table_name2 = $wpdb->prefix . 'plc_logs_link';
		$charset_collate2 = $wpdb->get_charset_collate();

		$sql2 = "CREATE TABLE $table_name2 (
			id 			mediumint(9) NOT NULL AUTO_INCREMENT, 
			username 	varchar(55) NOT NULL, 
			email 		varchar(80) NOT NULL,
                        plc_loginlink 	varchar(255) NOT NULL,
                        plc_token 		varchar(200) NOT NULL,
			date 		datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate2;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
        dbDelta( $sql2 );

	add_option( 'plc_version', PLC_VERSION );

}
register_activation_hook( __FILE__, 'plc_db_install' );


/**
 * When the plugin is updated, install it if User logs db table doesn't exist
 */
function plc_update_db_check() {

    $plc_version = get_option( 'plc_version' );

    if ( $plc_version != PLC_VERSION ) {

        global $wpdb;

		$table_name = $wpdb->prefix . 'plc_logs';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id 			mediumint(9) NOT NULL AUTO_INCREMENT, 
			username 	varchar(55) NOT NULL, 
			email 		varchar(80) NOT NULL, 
                        plc_loginlink 	varchar(255) NOT NULL,
			date 		datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate;";
                
                $table_name2 = $wpdb->prefix . 'plc_logs_link';
		$charset_collate2 = $wpdb->get_charset_collate();

		$sql2 = "CREATE TABLE $table_name2 (
			id 			mediumint(9) NOT NULL AUTO_INCREMENT, 
			username 	varchar(55) NOT NULL, 
			email 		varchar(80) NOT NULL,
                        plc_loginlink 		varchar(255) NOT NULL,
                        plc_token 		varchar(200) NOT NULL,
			date 		datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate2;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
                dbDelta( $sql2 );

		update_option( 'plc_version', PLC_VERSION );

    }

}
add_action( 'plugins_loaded', 'plc_update_db_check' );


?>