<?php
/**
 * PasswordLessCustom Shortcode
 */

/*if( is_user_logged_in()){
    $login= home_url()."/my-account";
    wp_redirect($login);
    exit;
} */

if($_REQUEST['plc_err_token']==TRUE){
    
    $plc_message = '<span style="font-size: 14px; color: red; font-weight: bold;">Your Link is Expired</span>';
}



if($_REQUEST['action']=="send_passwordlesslink"){
    $action    = "passwordlessurl";
    $account   = $_REQUEST['plc_username_email'];
    $plc_nonce = $_REQUEST['plc_nonce'];
    
    /* Check the userid or email exist */
    if ( is_email( $account ) ) {
		$account = sanitize_email( $account );
	} else {
		$account = sanitize_user( $account );
	}

	if ( is_email( $account ) && email_exists( $account ) ) {
		$account = $account;
                $user = get_user_by( 'email', $account );
	}

	elseif ( !is_email( $account ) && username_exists( $account ) ) {
		$user = get_user_by( 'login', $account );
		$account = $user->data->user_email;
                $user = get_user_by( 'email', $account );
        }else{
            
          echo "Userid or Email does not exist";  
        }
        
        $password= plc_generate_url($account,$plc_nonce);
        
        
      
        $to_email = $account;
        $subject = "PasswordLessCustom Login Link";
        //$body = "Hi,</br></br>". "Click On the link below </br></br>".$password."";
        $body = "<html><body><table border='0'>
            <tr><td>Hi,</td></tr>
            <tr><td></td></tr>
            <tr><td></td></tr>
            <tr><td>Click on link shown below for Login Without Password</td></tr>
            <tr><td>".$password."</td></tr>
            <tr><td></td></tr>
            <tr><td></td></tr>
            <tr><td>Thank You</td></tr>
                          
        </table></body></html>";
        $headers = "From: PasswordLessCustom Login \r\n";
        $headers .= 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-Type: text/html; charset=ISO-8859-1' . "\r\n";
        

        if (mail($to_email, $subject, $body, $headers)) {
            $plc_message = '<span style="font-size: 14px; color: green; font-weight: bold;">Login Link successfully sent to your emailid i.e. '.$to_email.'...</span>';
        } else {
            $plc_message = '<span style="font-size: 14px; color: red; font-weight: bold;"> Email sending failed...</span>';
        }
}


/**
 * Generates unique Passwordless URL based on UID and plc_nonce
 */
function plc_generate_url( $email = false, $plc_nonce = false) {

	if ( $email  == false ) {
		return false;
	}
	/* get user id */
	$user = get_user_by( 'email', $email );
	$token = plc_create_onetime_token( 'plc_' . $user->ID, $user->ID );
        

	$arr_params = array( 'plc_err_token', 'uid', 'token', 'plc_nonce' );
	$url = remove_query_arg( $arr_params, plc_curpageurl() );

        $url_params = array( 'uid' => $user->ID, 'token' => $token, 'plc_nonce' => $plc_nonce );

        $url = add_query_arg( $url_params, $url );
        
        global $wpdb;

			$table_name = $wpdb->prefix . 'plc_logs_link';
			$username = $user;
			$$tokenuseremail = $account;

			$wpdb->insert( 
				$table_name, 
				array( 
					'username' 	=> $user->user_login, 
					'email' 	=> $user->user_email,
                                        'plc_loginlink' => $url, 
                                        'plc_token' 	=> $token, 
					'date' 		=> current_time( 'mysql' )
				) 
			);

        //wp_mail($email,"Your Passwordless Link", "Your Passwordless Link is : ".$url ) ;
        
	return  $url;

}




/**
 * Create one time token that user only use once based on transients
 */
function plc_create_onetime_token( $action = -1, $user_id = 0 ) {

	$time = time();

	$expire_time = get_option( 'plc_expire_time', '1' );

	/* random salt */
	$key = wp_generate_password( 20, false );

	require_once( ABSPATH . 'wp-includes/class-phpass.php' );
	$wp_hasher = new PasswordHash(8, TRUE);
	$string = $key . $action . $time;

        $token  = wp_hash( $string );
	/* adjust the lifetime of the token. Currently 1 day. */
	$expiration = apply_filters( 'plc_change_link_expiration', ( $time + ( (int)$expire_time * 60 * 60 * 24 ) ) );
	$expiration_action = $action . '_expiration';
        
       /* echo $user_id; echo "<br>";
         echo $action; echo "<br>";
          echo $stored_hash; echo "<br>";
           echo $expiration_action; echo "<br>";
         echo   $expiration ; echo "<br>";
                 echo $usage_action;
                 */

	$usage_action = $action.'_usage_count' ; 
	
	$stored_hash = $wp_hasher->HashPassword( $token . $expiration );
	/* store a combination of token and expiration inside user meta */
	update_user_meta( $user_id, $action, $stored_hash );
	update_user_meta( $user_id, $expiration_action, $expiration );
	update_user_meta( $user_id, $usage_action, 0 );

	return $token;

}



 ?>
<?php  $currentloginuser_ID = get_current_user_id();
       if($currentloginuser_ID=="" or $currentloginuser_ID==0){
?>
<form name="plc_login_generator" class="plc_login_generator" id="plc_login_generator" action="" method="post">
                        <p><?php echo $plc_message ; ?></p> 
			<p>
				<label for="plc_username_email"><?php echo( apply_filters( 'plc_change_form_label', __('Please fill username or email in to produce passwordless login link', 'ss-generator') ) ) ; ?></label>
				<input type="text" name="plc_username_email" id="plc_username_email" class="plc_username_email" value="" size="25" />
			</p>
			
			<p>
                            <input type="hidden" name="action" id="action" value="send_passwordlesslink">
				<input type="submit" name="plc_submit" id="plc_submit" class="button button-primary plc_submit" value="<?php esc_attr_e('Generate', 'ss-generator'); ?>" />
			</p>
			<?php do_action('plc_generator_form'); ?>
			<?php wp_nonce_field( 'plc_passwordless_login_generator', 'plc_nonce', false ); ?>

		</form>
       <?php }else{?>
<p>Welcome ! <b><?php  $user_ID = get_current_user_id(); $user = get_user_by( 'ID', $user_ID ); echo $user->user_login;  ?></b></p>
       <?php } ?>
